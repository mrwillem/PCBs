 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: Z:\\45\\17\\4517301\\44\Eagle\2018-11-23_12-19-03\2018-11-23_12-19-03
 
 
**********************************************************
*****************Schematic Instructions  *******************
**********************************************************

To import your new Schematic file into Eagle:

1. Unzip the downloaded folder files to local directory and Start Eagle.
2. Select "File"->"Open"->"Schematic..." from the menu at the top of
the screen.
3. Browse to your newly exported file and select the ".sch" file extension.
4. You should now see your schamtic available in Eagle.

**********************************************************
*******************  PCB Instructions  *******************
**********************************************************

To import your new BOARD file into Eagle:

1. Unzip the downloaded folder files to local directory and Start Eagle.
2. Select "File"->"Open"->"Board..." from the menu at the top of
the screen.
3. Browse to your newly exported file and select the ".brd" file extension.
4. Planes will need to be repoured to update the polygon fills
	1. Once your board is loaded, type "ratsnest" into the command
	   line and press the Enter key.
	2. The polygons should all be filled now.
5. You should now have an image of your board available in Eagle.

**********************************************************
*******************  LIB Instructions  *******************
**********************************************************

To import your new library into Eagle:

1. Start Eagle.
2. Select "File"->"New"->"Library" from the menu.
3. In the blank library window, select "File" -> "Execute Script"
from the menu.
5. Browse to your newly exported Eagle Script file (".scr" file extension)
6. After opening the file, the script will populate the new library.
Layer 93 should NOT exist.
7. Use "File"->Save As: "AcceleratedDesigns_Lib.lbr" and to the desired
location in Eagle native format.
8. Update schematic with the imported library, Select Library and click on Update; open the library file
	and sync. each part.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Eagle_import.html

You may also find this video helpful:
http://youtu.be/5jGuWY-Yy3Q

**********************************************************
**********************************************************
**********************************************************
 
 
Component "UMK212B7104KG-T" renamed to "UMK212B7104KG-T"
Component "GRM188R71C223KA01D" renamed to "GRM188R71C223KA01D"
Component "CRCW080510K0FKEA" renamed to "CRCW080510K0FKEA"
Component "C3216C0G1H683J160AA" renamed to "C3216C0G1H683J160AA"
Component "C0402C112J5GAC7867" renamed to "C0402C112J5GAC7867"
Component "ERJ-6ENF3242V" renamed to "ERJ-6ENF3242V"
Component "C2012X5R1V106K085AC" renamed to "C2012X5R1V106K085AC"
Component "WB_CURRENT_LOAD" renamed to "WB_CURRENT_LOAD"
Component "SL44-E3/57T" renamed to "SL44-E3/57T"
Component "WB_GND" renamed to "WB_GND"
Component "MSS1260-123MLB" renamed to "MSS1260-123MLB"
Component "ERJ-6ENF1961V" renamed to "ERJ-6ENF1961V"
Component "TPS55340QRTERQ1" renamed to "TPS55340QRTERQ1"
Component "ERJ-6ENF2323V" renamed to "ERJ-6ENF2323V"
Component "C3216X5R1H685K160AB" renamed to "C3216X5R1H685K160AB"
Component "WB_BATTERY" renamed to "WB_BATTERY"
Component "C1608X5R1H105K080AB" renamed to "C1608X5R1H105K080AB"
The Symbol WB_CONTINUATION was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CONTINUATION was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CONTINUATION was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_CURRENT_LOAD was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_CURRENT_LOAD was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_CURRENT_LOAD was missing a Value attribute, a value was created for the symbol.
The Symbol WB_BLOCK_IO was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Type attribute, a type was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_VOLTAGE_SOURCE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_PWL_VOLTAGE_SOURCE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_PWL_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_PWL_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_STARTUP_VOLTAGE_SOURCE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_STARTUP_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_STARTUP_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_STARTUP_VOLTAGE_SOURCE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_STARTUP_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_STARTUP_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_TPS55340_Q1_Sync was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_TPS55340_Q1_Sync was missing a Type attribute, a type was created for the symbol.
The Symbol WB_TPS55340_Q1_Sync was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_PULSE_VOLTAGE_SOURCE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_PULSE_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_PULSE_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_DIODE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_DIODE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_DIODE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_TPS55340-Q1 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_TPS55340-Q1 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_TPS55340-Q1 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_COUTX_BLOCK was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_COUTX_BLOCK was missing a Type attribute, a type was created for the symbol.
The Symbol WB_COUTX_BLOCK was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_CAPACITOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_CAPACITOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_CAPACITOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_INDUCTOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_INDUCTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_INDUCTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_AC_VOLTAGE_SOURCE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_AC_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_AC_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_COUTX_AC_BLOCK was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_COUTX_AC_BLOCK was missing a Type attribute, a type was created for the symbol.
The Symbol WB_COUTX_AC_BLOCK was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Value attribute, a value was created for the symbol.


Ultra Librarian Gold 8.1.204 Process Report


Message - Padstack "RX44Y57D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX26Y38D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX44Y71D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX22Y24D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX71Y117D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX157Y217D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX11p81Y19p69D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX64p96Y64p96D0T" Shape(4) is a CIRCLE with no diameter.
Message - Pattern "MSS1260", entity (114-Line) is a LINE with matching start and end points.
Message - Pattern "MSS1260", entity (116-Line) is a LINE with matching start and end points.
Message - Pattern "MSS1260", entity (118-Line) is a LINE with matching start and end points.
Message - Pattern "MSS1260", entity (120-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (232-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (288-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (290-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (293-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (295-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (298-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (300-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (303-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (305-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (308-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (310-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (313-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (315-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (318-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (320-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (323-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (325-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (328-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (330-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (333-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (335-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (338-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (340-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (343-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (345-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (348-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (350-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (353-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (355-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (358-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (360-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (363-Line) is a LINE with matching start and end points.
Message - Pattern "S-PWQFN-N16", entity (365-Line) is a LINE with matching start and end points.
Message - Symbol "WB_CAPACITOR" has as multiple attributes named "TYPE".
One of the attributes was renamed to "TYPE_2".
Message - Component "UMK212B7104KG-T" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "UMK212B7104KG-T" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "UMK212B7104KG-T" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "UMK212B7104KG-T" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R71C223KA01D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R71C223KA01D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R71C223KA01D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R71C223KA01D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW080510K0FKEA" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW080510K0FKEA" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW080510K0FKEA" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3216C0G1H683J160AA" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3216C0G1H683J160AA" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3216C0G1H683J160AA" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3216C0G1H683J160AA" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3216C0G1H683J160AA" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0402C112J5GAC7867" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0402C112J5GAC7867" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0402C112J5GAC7867" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0402C112J5GAC7867" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0402C112J5GAC7867" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF3242V" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF3242V" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF3242V" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1V106K085AC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1V106K085AC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1V106K085AC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1V106K085AC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1V106K085AC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SL44-E3/57T" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SL44-E3/57T" attribute "Io" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SL44-E3/57T" attribute "VRRM" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SL44-E3/57T" attribute "VFatIo" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MSS1260-123MLB" attribute "L" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MSS1260-123MLB" attribute "DCR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MSS1260-123MLB" attribute "IDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1961V" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1961V" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF1961V" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS55340QRTERQ1" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS55340QRTERQ1" attribute "Frequency" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS55340QRTERQ1" attribute "Imax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS55340QRTERQ1" attribute "Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS55340QRTERQ1" attribute "Mktg_Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS55340QRTERQ1" attribute "NSID" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF2323V" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF2323V" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "ERJ-6ENF2323V" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3216X5R1H685K160AB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3216X5R1H685K160AB" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3216X5R1H685K160AB" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3216X5R1H685K160AB" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C3216X5R1H685K160AB" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H105K080AB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H105K080AB" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H105K080AB" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H105K080AB" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H105K080AB" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.

TextStyle count:  24
Padstack count:   8
Pattern count:    8
Symbol count:     29
Component count:  17

Export

Component "WB_CURRENT_LOAD" has no mapped footprint will be skipped.
Component "WB_GND" has no mapped footprint will be skipped.
Component "WB_BATTERY" has no mapped footprint will be skipped.
